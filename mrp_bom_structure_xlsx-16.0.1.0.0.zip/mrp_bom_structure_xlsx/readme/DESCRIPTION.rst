This module extends the functionality of the MRP capabilities of Odoo,
and allow you to export the BoM structure to MS Excel .XLSX format.
