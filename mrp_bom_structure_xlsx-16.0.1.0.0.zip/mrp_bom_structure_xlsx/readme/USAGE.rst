To use this module, you need to:

Go to the Bill of Materials form or list views, press 'Print > Export BoM
Structure to Excel'.
