To install this module, you need to:

#. Go to apps
#. Look for mrp_bom_structure_xlsx module
#. Click install
