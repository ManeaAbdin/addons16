## Module <pos_access_right_hr>

#### 04.05.2023
#### Version 16.0.1.0.0
##### ADD
- Initial commit for POS Access Right