This module has been financially supported by:

* Inovera <https://www.inovera.lt>
* Akretion Brazil <https://www.akretion.com.br>
* Akretion <https://www.akretion.com>
* Savoir-faire Linux <https://www.savoirfairelinux.com>
* Credativ <https://www.credativ.co.uk>
* Vauxoo <https://www.vauxoo.com>
* Camp 2 Camp <https://camptocamp.com>
* Open Source Integrators <https://www.opensourceintegrators.com>
