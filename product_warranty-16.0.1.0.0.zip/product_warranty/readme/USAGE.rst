To use this module, you need to:

#. Go to *Sales > Products > Products (or Product Variants)*
#. Create a new product (or product variant) or edit an existing one
   and set 'Warranty Duration' under 'Sales' tab.
#. If 'Purchase' module is installed, got to
   *Sales > Products > Products (or Product Variants)*, go to 'Purchase' tab,
   edit supplier information lines an set the warranty information for each one.
