# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

from . import return_instruction, product_supplierinfo, res_company, product_template
