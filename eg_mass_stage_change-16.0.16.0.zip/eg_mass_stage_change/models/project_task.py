from  odoo import fields, models

class ProjectTask(models.Model):
    _inherit = 'project.task'

    def mass_project_task_stage_change(self):
        return {
            'name': "Bulk Tasks Stage Change",
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'task.stage.change',
            'context': dict(self._context, active_ids=self.ids),
            'target': 'new',
        }
