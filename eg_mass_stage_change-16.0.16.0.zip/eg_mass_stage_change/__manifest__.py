{
    'name': 'Project Mass Stage Change',
    'version': '16.0',
    'category': 'Project',
    'depends': ['project'],
    'license': 'OPL-1',
    "author": "INKERP",
    'website': "https://www.INKERP.com",
    
    'data': [
        'security/ir.model.access.csv',
        'views/project_task_view.xml',
        'Wizard/task_stage_change_view.xml',
        'Wizard/msg_wizard_view.xml',
    ],


    'images': ['static/description/banner.png'],
    'license': "OPL-1",
    'installable': True,
    'application': True,
    'auto_install': False,
}
