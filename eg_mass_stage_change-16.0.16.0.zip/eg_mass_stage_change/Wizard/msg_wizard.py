from odoo import fields, models

class MsgWizard(models.Model):
    _name = 'msg.wizard'

    text = fields.Text(string="Message")