from odoo import fields, models, _

class TaskStageChange(models.Model):
    _name = 'task.stage.change'

    task_type_id = fields.Many2one(comodel_name='project.task.type',string="Select Stage")

    def action_task_stage_change(self):
        if self._context.get('active_ids'):
            for task_id in self._context.get('active_ids'):
                task_id = self.env['project.task'].search([('id','=', task_id)])
                if self.task_type_id in task_id.project_id.type_ids:
                    task_id.stage_id = self.task_type_id.id

            msg = _("Your tasks stage Updated successfully.")
            partial_id = self.env['msg.wizard'].create({'text': msg})
            return {
                'name': "Message",
                'view_mode': 'form',
                'view_id': False,
                'view_type': 'form',
                'res_model': 'msg.wizard',
                'res_id': partial_id.id,
                'type': 'ir.actions.act_window',
                'nodestroy': True,
                'target': 'new',
            }



