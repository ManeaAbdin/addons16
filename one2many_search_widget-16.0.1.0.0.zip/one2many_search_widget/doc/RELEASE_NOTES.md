## Module <one2many_search_widget>

#### 03.04.2023
#### Version 16.0.1.0.0
#### ADD
- Initial commit for One2many Search Widget


