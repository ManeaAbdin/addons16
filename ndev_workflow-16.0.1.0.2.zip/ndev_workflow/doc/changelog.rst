.. _changelog:

Changelog
=========

`1.0.2`
----------------
- Add process data (key, id, version) and fix bugs

- Add corezoid connector

- Remove from branches excessive data

`1.0.1`
----------------

- Add my workflows.

- Add security group

- Add server authorizations

- Server calls encapsulation


`1.0.0`
----------------

- Init version.

- Basic workflow with related activities and processes

- Processes as  workflow part started from base_automation

- Server as asset
