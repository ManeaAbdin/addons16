{
    'name': 'Workflows',
    'category': 'Productivity/Workflow',
    'summary': 'Allows build workflows for activity',
    'version': '1.0.2',
    'author': "Svyatoslav Nadozirny",
    'website': "https://ndev.online",
    'maintainer': 'NDev',

    'description': """
        Allows build workflows for activity.
        """,
    'depends': [
        'base_automation'
    ],
    'data': [
        'security/workflow_security.xml',
        'security/ir.model.access.csv',
        'views/mail_activity_views.xml',
        'views/workflow_views.xml',
        'views/process_views.xml',
        'views/server_views.xml',
        'views/base_automation.xml',
        'views/workflow_menus.xml',
        'data/workflow_sequence.xml',
        'data/mail_activity_data.xml',
        'data/ir_cron_data.xml',

    ],
    'images': ['static/description/banner.png'],
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}
