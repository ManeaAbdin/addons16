from odoo import models, fields


class MailActivity(models.Model):
    _inherit = "mail.activity"
    workflow_id = fields.Many2one(comodel_name="workflow.workflow")
    correlation_id = fields.Char()
    resolution = fields.Selection(selection=[
        ('approve', 'Approve'),
        ('decline', 'Decline'),
    ])
