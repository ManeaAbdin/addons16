from odoo import models, fields, api
import logging

class Process(models.Model):
    _name = 'workflow.process'
    _description = 'Basic process model'

    name = fields.Char(required=True)
    key = fields.Char()
    pid = fields.Char(readonly=True)
    definition = fields.Text()
    version = fields.Integer(readonly=True)
    server_id = fields.Many2one("workflow.server", required=True)
    startable = fields.Boolean()
    type = fields.Char(compute='_get_type')

    @api.onchange('server_id')
    def _get_type(self):
        for r in self:
            if r.server_id:
                r.type=r.server_id.type

    def start(self, data):
        self.ensure_one()
        logging.getLogger(__name__).debug(f"Start process {self.test}/{self.name}")

