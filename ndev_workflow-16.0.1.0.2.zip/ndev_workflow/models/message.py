import json
from datetime import timedelta
from odoo import api, fields, models, _



class Message(models.Model):
    _name = "workflow.message"
    _description = "Message model for exchange with external systems"

    state = fields.Selection(selection=[
        ('draft','Draft'),
        ('ready','Ready'),
        ('done','Done'),
        ('failed','Failed'),
      ],default='draft')
    type = fields.Selection(selection=[
        ('internal','Internal'),
        ('in','Input'),
        ('out','Output'),
      ], required=True)

    properties = fields.Text(default="{}",help="Properties represented in JSON format")
    body = fields.Text()
    error = fields.Text()
    source_id = fields.Many2one(comodel_name="workflow.server")
    target_id = fields.Many2one(comodel_name="workflow.server")
    model_id = fields.Many2one('ir.model', string='Model', required=True, ondelete='cascade',
                               help="Model on which the server action runs.")
    model_name = fields.Char(related='model_id.model', string='Model Name', readonly=True, store=True)
    source_name = fields.Char()

    def vacuum_done(self):
        self.search([('state','=','done'),('create_date','<',fields.Datetime.now() - timedelta(days=1) )]).unlink()
