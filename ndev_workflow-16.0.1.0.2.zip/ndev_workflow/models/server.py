import requests
from odoo import models, fields, api
import logging

logger = logging.getLogger(__name__)

STANDART_PORTS = {
    'http': 80,
    'https': 443,
}


class Server(models.Model):
    _name = 'workflow.server'
    _description = 'Workflow server model'

    name = fields.Char(required=True)
    host = fields.Char(required=True)
    path = fields.Char()
    port = fields.Integer()
    user = fields.Char()
    password = fields.Char()
    url = fields.Char(readonly=True, compute="_compute_url")
    process_ids = fields.One2many(comodel_name="workflow.process", inverse_name="server_id", string="Processes")
    source_message_ids = fields.One2many(comodel_name="workflow.message", inverse_name="source_id")
    target_message_ids = fields.One2many(comodel_name="workflow.message", inverse_name="target_id")
    authorization = fields.Selection(selection=[
        ('no', 'No authorization'),
        ('basic', 'Basic HTTP'),
    ], default='no')

    type = fields.Selection(selection=[
        ('test', 'Test'),
    ], default='test')

    schema = fields.Selection(selection=[
        ('http', 'HTTP'),
        ('https', 'HTTPs'),
    ], default='http')

    @api.onchange('schema')
    def _compute_port(self):
        for r in self:
            if r.schema == 'http':
                r.port = 80
            if r.schema == 'https':
                r.port = 443

    @api.depends('schema', 'host', 'user', 'password', 'port', 'path')
    def _compute_url(self):
        for r in self:
            if r.authorization == 'no' and r.user:
                authorization = f"{r.user}:{r.password}@"
            else:
                authorization = ""
            if r.port != STANDART_PORTS.get(r.schema):
                port = f":{r.port}"
            else:
                port = ''
            r.url = f"{r.schema}://{authorization}{r.host}{port}{'/' + r.path if r.path else ''}"

    def post_json(self, url, data):
        if self.authorization == 'basic':
            result=requests.post(url, json=data, auth=(self.user, self.password))
        else:
            result=requests.post(url, json=data)
        if result.content:
            return result.json()
        else:
            return {}

    def get_json(self, url):
        if self.authorization == 'basic':
            return requests.get(url, auth=(self.user, self.password)).json()
        else:
            return requests.get(url).json()

    def get(self, url):
        if self.authorization == 'basic':
            return requests.get(url, auth=(self.user, self.password))
        else:
            return requests.get(url)

    def post(self, url, data):
        if self.authorization == 'basic':
            return requests.post(url, auth=(self.user, self.password), data=data)
        else:
            return requests.post(url,data=data)


    def put(self, url, data):
        if self.authorization == 'basic':
            return requests.put(url, auth=(self.user, self.password), data=data)
        else:
            return requests.put(url,data=data)

    def patch(self, url, data):
        if self.authorization == 'basic':
            return requests.patch(url, auth=(self.user, self.password), data=data)
        else:
            return requests.patch(url,data=data)

    def delete(self, url, data):
        if self.authorization == 'basic':
            return requests.delete(url, auth=(self.user, self.password), data=data)
        else:
            return requests.delete(url,data=data)