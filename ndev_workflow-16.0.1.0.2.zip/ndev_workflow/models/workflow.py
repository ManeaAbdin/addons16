from odoo import models, fields, api, _
import logging

logger=logging.getLogger(__name__)

class WorkflowNameValue(models.Model):
    _name = "workflow.workflow.name.value"
    name = fields.Char(required=True)
    value = fields.Char()
    workflow_id = fields.Many2one(comodel_name="workflow.workflow")


class Workflow(models.Model):
    _name = "workflow.workflow"

    name = fields.Char(readonly=True, default=lambda self: _('New'))
    activity_ids = fields.One2many(comodel_name='mail.activity', inverse_name="workflow_id", string="Activities")
    data_ids = fields.One2many(comodel_name='workflow.workflow.name.value', inverse_name="workflow_id")
    user_id = fields.Many2one(comodel_name="res.users", string="Responsible", default=lambda self: self.env.user,
                              readonly=True)
    process_instance_id = fields.Char(readonly=True)
    process_id = fields.Many2one(comodel_name="workflow.process")
    state = fields.Selection(selection=[
        ('draft', 'Draft'),
        ('in_progress', 'In progress'),
        ('done', 'Done'),
        ('failed', 'Failed'),
    ], readonly=True, default='draft')

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('workflow_workflow')
        res = super(Workflow, self).create(vals)
        logger.info(vals.get('data_ids'))
        if vals.get('data_ids'):
            for id,name,data in vals.get('data_ids'):
                data['workflow_id']=res.id
                res.data_ids.create(data)
        return res

    def start(self):
        self._start({})

    def _start(self, data):
        for record in self:
            for name in data.keys():
                record.data_ids.create({
                    'workflow_id': record.id,
                    'name': name,
                    'value': data[name]
                })
            record.state = 'in_progress'
