from odoo import models, fields


class ServerAction(models.Model):
    _inherit = 'ir.actions.server'
    #usage = fields.Selection(selection_add=[('workflow', 'Start workflow')], ondelete={'workflow': 'cascade'})
    state = fields.Selection(selection_add=[('workflow', 'Start process')], ondelete={'workflow': 'cascade'})
