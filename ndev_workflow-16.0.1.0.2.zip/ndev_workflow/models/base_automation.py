from odoo import models, fields
import logging

logger = logging.getLogger(__name__)


class BaseAutomation(models.Model):
    _inherit = 'base.automation'

    process_id = fields.Many2one(comodel_name="workflow.process")

    def _process(self, records, domain_post=None):
        if self.state == "workflow":
            for record in records:
                workflow_model = self.env["workflow.workflow"]
                workflow = workflow_model.create({
                    'process_id': self.process_id.id,
                })
                data = {
                    'res_model_id': self.action_server_id.model_id.id,
                    'res_model_name': self.action_server_id.model_name,
                    'res_id': record.id,
                    'name': record.name,
                    'trigger': self.trigger,
                    'fields': {}
                }
                model_fields = self.env['ir.model.fields'].sudo().search([('model', '=', self.action_server_id.model_name)])
                for field in model_fields:
                    if field.ttype not in ['binary']:
                        data['fields'][field.name] = getattr(record, field.name)
                workflow._start(data)
        else:
            super(BaseAutomation, self)._process(records, domain_post)
