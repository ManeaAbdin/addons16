To use this module, you need to:

#. Go to *Settings* and *Activate the developer mode*
#. Go to *Invoicing*.
#. Create a Invoice and specify a fixed discount in a line.
