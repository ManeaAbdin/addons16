## Module <user_login_alert>

#### 05.09.2022
#### Version 16.0.1.0.0
#### ADD
Migration Of User Login Alert

#### 26.09.2023
#### Version 16.0.1.0.1
#### BUGFIX
- Bug Fix: Fixed an issue with the email sending function. Access issue resolved
