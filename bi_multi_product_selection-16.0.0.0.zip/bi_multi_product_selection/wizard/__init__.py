# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.

from . import sale_order_wizard
from . import purchase_order_wizard
from . import account_move_wizard
from . import stock_picking_wizard