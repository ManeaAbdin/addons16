Livedigital :- Restrict Concurrent User Login

------------------------

* Restrict concurrent sessions in your Odoo ERP.