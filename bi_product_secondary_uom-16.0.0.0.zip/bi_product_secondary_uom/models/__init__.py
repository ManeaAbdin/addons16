# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.

from . import product
from . import stock_quant
from . import sale_order_line
from . import purchase_order_line
from . import stock_move