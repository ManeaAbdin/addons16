# -*- coding: utf-8 -*-

{
    'name': 'RFQ Approve from List View',
    'version': '16.0.1.0.0',
    'category': 'Inventory/Purchase',
    'license': 'LGPL-3',
    'summary': """Approve your RFQ from list views""",
    'depends': [
        'base',
        'purchase',
    ],
    'author': 'SugarClone ERP',
    'support': 'sugarcloneerp@gmail.com',
    'description': """ Updates Below
    - Approve and cancel purchase order from list view
    """,
    'data': [
        'views/purchase_order_views.xml',
    ],
    'images': ['static/description/banner.png'],
    'installable': True,
    'auto_install': False,
    'application': False,
}
