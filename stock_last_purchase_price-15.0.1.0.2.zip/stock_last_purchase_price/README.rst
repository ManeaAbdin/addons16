Costing Method:Last Purchase Price
==================================

This module introduces a new costing method to Odoo. That will update a product's cost price when a new purchase
happens with the purchasing rate. if you enables automatic stock valuation and provided a price difference account,
this module will generate stock journal entry to update the stock value according to the price change.

Installation
============
- www.odoo.com/documentation/14.0/setup/install.html
- Install our custom addon


Bug Tracker
===========
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Credits
=======
* Cybrosys Techno Solutions <https://www.cybrosys.com>

Author
------
* Fasluca <faslu@cybrosys.in>
* Sreenath
* Shijin
