Give the user permissions to view full accounting features, then go to
'Invoicing / Accounting / Mass Automatic Reconcile' to start a new mass
reconcile.
