* Make it totally multi-company aware.
* Be multi-currency aware for settlements.
* Allow to calculate and pay in other currency different from company one.
* Set agent popup window with a kanban view with richer information and
  mobile friendly.
