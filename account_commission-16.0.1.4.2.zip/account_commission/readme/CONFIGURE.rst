For selecting invoice status in commissions:

#. Edit or create a new record to select the invoice status for settling the commissions.

   * **Invoice Based**: Commissions are settled when the invoice is issued.
   * **Payment Based**: Commissions are settled when the invoice is paid.
