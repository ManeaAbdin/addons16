## Module <product_management_app>

#### 17.01.2023
#### Version 16.0.1.0.0
#### ADD
- Initial commit for Product Management Module 
