## Module <so_bom_selection>

####  01.04.2023
#### Version 16.0.1.0.0
#### ADD

- Initial commit for Bill Of Material from Sale Order Line
