# -*- coding: utf-8 -*-


from .hook import post_init_hook

