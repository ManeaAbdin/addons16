#. Go to the model's menu entry for which you have defined the filter.
#. On the filters and group by dropdowns, you will see the configured filters.
