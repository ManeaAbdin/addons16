This module allows to define custom filters to be shown under the standard
filters and group by menus of a model's search view.
