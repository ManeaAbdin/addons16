This module implements a component system and is a base block for the Connector
Framework. It can be used without using the full Connector though.

Documentation: http://odoo-connector.com/

You may also want to check the `Introduction to Odoo Components`_ by @guewen.

.. _Introduction to Odoo Components: https://dev.to/guewen/introduction-to-odoo-components-bn0
