.. [ The change log. The goal of this file is to help readers
    understand changes between version. The primary audience is
    end users and integrators. Purely technical changes such as
    code refactoring must not be mentioned here.

    This file may contain ONE level of section titles, underlined
    with the ~ (tilde) character. Other section markers are
    forbidden and will likely break the structure of the README.rst
    or other documents where this fragment is included. ]

16.0.1.0.0 (2022-10-04)
~~~~~~~~~~~~~~~~~~~~~~~

* [MIGRATION] from 15.0

15.0.1.0.0 (2021-11-25)
~~~~~~~~~~~~~~~~~~~~~~~

* [MIGRATION] from 14.0

14.0.1.0.0 (2020-10-22)
~~~~~~~~~~~~~~~~~~~~~~~

* [MIGRATION] from 13.0

13.0.1.0.0 (2019-10-23)
~~~~~~~~~~~~~~~~~~~~~~~

* [MIGRATION] from 12.0

12.0.1.0.0 (2018-10-02)
~~~~~~~~~~~~~~~~~~~~~~~

* [MIGRATION] from 11.0 branched at rev. 324e006
