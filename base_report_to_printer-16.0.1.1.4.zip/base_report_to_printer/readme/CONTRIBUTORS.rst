* Ferran Pegueroles <ferran@pegueroles.com>
* Albert Cervera i Areny <albert@nan-tic.com>
* Davide Corio <davide.corio@agilebg.com>
* Lorenzo Battistini <lorenzo.battistini@agilebg.com>
* Yannick Vaucher <yannick.vaucher@camptocamp.com>
* Lionel Sausin <ls@numerigraphe.com>
* Guewen Baconnier <guewen.baconnier@camptocamp.com>
* Dave Lasley <dave@laslabs.com>
* Sylvain Garancher <sylvain.garancher@syleam.fr>
* Jairo Llopis <jairo.llopis@tecnativa.com>
* Graeme Gellatly <graeme@o4sb.com>
* Rod Schouteden <rod@schout-it.be>
* Alexandre Fayolle <alexandre.fayolle@camptocamp.com>
* Matias Peralta <mnp@adhoc.com.ar>
* Hughes Damry <hughes.damry@acsone.eu>
* Akim Juillerat <akim.juillerat@camptocamp.com>
