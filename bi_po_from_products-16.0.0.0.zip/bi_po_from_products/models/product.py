from odoo import api, fields, models, _


class Productproduct(models.Model):
    _inherit = "product.product"
