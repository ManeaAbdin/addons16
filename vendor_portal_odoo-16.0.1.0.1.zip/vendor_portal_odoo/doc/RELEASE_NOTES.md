## Module <vendor_portal_odoo>

#### 24.04.2023
#### Version 16.0.1.0.0
##### ADD
- Initial commit for Odoo Vendor Portal

#### 08.09.2023
#### Version 16.0.1.0.1
##### UPDT
- Registered Vendors Bug fix
