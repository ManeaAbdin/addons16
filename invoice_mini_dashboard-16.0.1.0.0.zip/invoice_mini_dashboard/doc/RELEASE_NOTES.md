## Module <invoice_mini_dashboard>

#### 11.08.2023
#### Version 16.0.1.0.0
#### ADD
-- Initial commit for Invoice Mini Dashboard

