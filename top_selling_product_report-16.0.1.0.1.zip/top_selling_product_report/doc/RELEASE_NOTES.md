## Module <top_selling_product_report>

#### 17.10.2020
#### Version 16.0.1.0.0
##### ADD
- Initial commit for Top Selling Product Report

#### 21.07.2023
#### Version 16.0.1.0.1
##### FIX
- Updated the report to include the sold product data from the Point of Sale (POS) module when installed.
