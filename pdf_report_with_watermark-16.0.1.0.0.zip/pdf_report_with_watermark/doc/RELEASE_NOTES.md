## Module <pdf_report_with_watermark>
#### 20.03.2023
#### Version 16.0.1.0.0
##### ADD
- Initial Commit for Reports With Watermark
