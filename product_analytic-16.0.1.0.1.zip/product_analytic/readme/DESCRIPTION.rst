This module allows to define an analytic account at product or category level
for using it when creating invoices.
