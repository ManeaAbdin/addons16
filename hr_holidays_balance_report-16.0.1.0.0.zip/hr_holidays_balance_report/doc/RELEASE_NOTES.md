## Module <hr_holidays_balance_report>

#### 22.02.2023
#### Version 16.0.1.0.0
#### ADD
- Initial Commit for HR Balance Leave Report
