## Module <margin_product_sale_invoice>

#### 27.10.2023
#### Version 16.0.1.0.0
#### ADD
- Initial commit for Margin on Products, Sales & Invoices

