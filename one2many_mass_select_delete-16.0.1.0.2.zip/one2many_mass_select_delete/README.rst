======================================
One2many Mass Select Delete Widget v16
======================================

One2many Mass Select/Deselect Widget.

Installation
============
Just select it from available modules to install it, there is no need to extra installations.

Configuration
=============

<field name="order_lines" widget="one2many_delete">


Features
========
* Mass Selection.
* Mass Deletion.

Credits
=======
Developer: Nilmar Shereef @ cybrosys, shereef@cybrosys.in
           version 16: Gayathri@cybrosys


