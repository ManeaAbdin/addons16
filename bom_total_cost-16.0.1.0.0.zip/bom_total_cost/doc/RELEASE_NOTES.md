## Module <bom_total_cost>

#### 21.02.2023
#### Version 16.0.1.0.0
#### ADD
- Initial Commit for Total Cost in BOM