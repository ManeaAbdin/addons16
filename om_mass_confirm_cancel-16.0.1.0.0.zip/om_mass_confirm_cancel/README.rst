=====================================
Sale,Purchase Mass Confirm and Cancel
=====================================

Allow To Cancel and Confirm the Sales and Purchase From the Tree View


Usage
=====

* In Sale and Purchase Tree View

Bug Tracker
===========

In case of any trouble using this module, please get in touch with us.

Authors
~~~~~~~

Odoo Mates

Support
=======
Email : odoomates@gmail.com

Maintainers
~~~~~~~~~~~

This module is maintained by the Odoo Mates.
