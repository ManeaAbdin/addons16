## Module <om_mass_confirm_cancel>

#### 10.12.2021
#### Version 15.0.1.0.0
##### ADD
- initial commit

