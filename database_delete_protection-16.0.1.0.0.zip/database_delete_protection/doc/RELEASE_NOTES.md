## Module <database_delete_protection>
#### 21.03.2023
#### Version 16.0.1.0.0
##### ADD
- Initial commit for Database Delete Protection
