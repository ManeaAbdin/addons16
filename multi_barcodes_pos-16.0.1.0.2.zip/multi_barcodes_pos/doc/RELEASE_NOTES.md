## Module <multi_barcodes_pos>

#### 21.09.2022
#### Version 16.0.1.0.0
##### ADD
- Initial commit for POS Multi Barcode Scan

#### 10.04.2023
#### Version 16.0.1.0.1
##### FIX
- Bug Fix: added validation for the field multi_barcode to avoid duplication of barcodes