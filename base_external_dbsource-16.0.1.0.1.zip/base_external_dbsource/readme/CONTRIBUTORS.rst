* Daniel Reis <dreis.pt@hotmail.com>
* Maxime Chambreuil <maxime.chambreuil@savoirfairelinux.com>
* Gervais Naoussi <gervaisnaoussi@gmail.com>
* Dave Lasley <dave@laslabs.com>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Sergio Teruel
  * Jairo Llopis
  * Andrea Cattalani (`Moduon <https://www.moduon.team/>`__)
