* Go to Settings > Technical > Database Structure > Database Sources
* Click on Create to enter the following information:

* Data source name 
* Password
* Connector: Choose the database to which you want to connect
* Connection string: Specify how to connect to database
