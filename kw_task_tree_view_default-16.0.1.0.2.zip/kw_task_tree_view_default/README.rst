Task tree view by default
=========================

Makes tree view default for all project task views

This module is developed by the `KitWorks <https://kitworks.systems/>`__.
