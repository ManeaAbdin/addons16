# -*- coding: utf-8 -*-

from . import dynamic_report_configure
from . import inherit_ir_actions
