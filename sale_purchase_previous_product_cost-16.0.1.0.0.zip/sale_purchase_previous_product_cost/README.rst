Previous Sale/Purchase Product Rates V16
========================================
This module enables a view to see all previous sale/purchase product rates of selected customer.


Configuration
=============
* No additional configurations needed

Company
-------
* `Cybrosys Techno Solutions <https://cybrosys.com/>`__

Credits
-------
* Developers: 	Nilamr Shereef @cybrosys, odoo@cybrosys.com,
 		V11 Niyas Raphy @cybrosys, odoo@cybrosys.com,
		V12 Vinaya S B odoo@cybrosys.com,
        V13 Mehjabin Farsana P @cybrosys,odoo@cybrosys.com,
        V14 Minhaj T @cybrosys,odoo@cybrosys.com,
        V15 Midilaj V K @cybrosys,odoo@cybrosys.com,
        V16 Sahla Sherin @cybrosys,odoo@cybrosys.com

Contacts
--------
* Mail Contact : odoo@cybrosys.com
* Website : https://cybrosys.com

Bug Tracker
-----------
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Maintainer
==========
.. image:: https://cybrosys.com/images/logo.png
   :target: https://cybrosys.com

This module is maintained by Cybrosys Technologies.

For support and more information, please visit `Our Website <https://cybrosys.com/>`__

Further information
===================
HTML Description: `<static/description/index.html>`__




