## Module <sale_purchase_previous_product_cost>

#### 30.11.2021
#### Version 16.0.1.0.0
#### ADD
Initial Commit Previous Sale/Purchase Product Rates



