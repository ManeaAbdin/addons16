* Stéphane Bidoul <stephane.bidoul@acsone.eu>
* Alexis de Lattre <alexis.delattre@akretion.com>
* Adrien Peiffer <adrien.peiffer@acsone.eu>
* Stefan Rijnhart
* Laurent Mignon <laurent.mignon@acsone.eu>
* Alexandre Fayolle
* Danimar Ribeiro
* Erwin van der Ploeg
* Raphaël Valyi
* Sandy Carter
* Angel Moya <angel.moya@domatix.com>
* Jose María Alzaga <jose.alzaga@aselcis.com>
* Meyomesse Gilles <meyomesse.gilles@gmail.com>
* Denis Roussel <denis.roussel@acsone.eu>

* `DynApps <https://www.dynapps.be>`_:

  * Raf Ven <raf.ven@dynapps.be>
* Andrea Stirpe <a.stirpe@onestein.nl>
* `Jarsa <https://www.jarsa.com.mx>`_:

  * Alan Ramos <alan.ramos@jarsa.com.mx>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza
  * Carlos Dauden
  * Carlos Roca

* `Open Source Integrators <https://www.opensourceintegrators.com>`_:

  * Ammar Officewala <aofficewala@opensourceintegrators.com>
* Marçal Isern <marsal.isern@qubiq.es>
