## Module <activity_dashboard_mngmnt>

#### 16.12.2022
#### Version 16.0.1.0.0
##### ADD

- Initial commit for Activity Management

#### 10.08.2022
#### Version 16.0.1.1.0
##### UPDT

- Bug fix. 
- User can see their own activity.
- Admin can see all activity.
- Performance updates.
