## Module <odoo_product_expiry_dashboard>

#### 13.10.2023
#### Version 15.0.1.0.0
#### ADD

- Initial commit for Product Expiry Dashboard
