## Module <print_minutes_of_meeting>

#### 02.01.2023
#### Version 16.0.1.0.0
#### ADD
Initial Commit Minutes of Meetings and Print Meetings
