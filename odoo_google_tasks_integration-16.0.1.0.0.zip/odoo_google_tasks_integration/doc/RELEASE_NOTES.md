## Module <odoo_google_tasks_integration>

#### 22.09.2023
#### Version 16.0.1.0.0
#### ADD
- Initial commit for Sync Google Task With Project Task
