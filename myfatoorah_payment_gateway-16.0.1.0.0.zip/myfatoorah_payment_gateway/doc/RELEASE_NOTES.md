## Module <myfatoorah_payment_gateway>

#### 28.12.2022
#### Version 16.0.1.0.0
#### ADD
Initial Commit

#### 18.10.2023
#### Version 16.0.1.0.1
#### ADD
The payment fail issue is fixed