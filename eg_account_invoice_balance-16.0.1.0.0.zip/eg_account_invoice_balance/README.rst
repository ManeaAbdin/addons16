=================================
Customer Balance in Invoice
=================================
This app will help  user to provide users with the ability to view and verify customer credit notes on both the invoice form view and invoice PDF.
