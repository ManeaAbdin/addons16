Create SQL Scripts for Encrypt and Decrypt  Personal Information
==================================================================================
* "Create SQL Scripts for Encrypt and Decrypt  Personal Information

Installation
============
	- www.odoo.com/documentation/16.0/setup/install.html
	- Install our custom addon
	- How to use:
	  Go to the Model select the model/fields you want to encrypt the data and run the method via action


License
-------
General Public License, Version 3 (LGPL v3).
(https://www.odoo.com/documentation/user/16.0/legal/licenses/licenses.html)



Credits
-------
* Developer:
(v16) Guilherme Marcondes


Contacts
--------
* Mail Contact : gulhermemarcondes4@msn.com


Bug Tracker
-----------
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.


