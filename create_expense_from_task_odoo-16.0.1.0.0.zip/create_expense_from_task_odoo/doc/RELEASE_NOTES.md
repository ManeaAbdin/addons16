## Module <create_expense_from_task_odoo>

#### 10.04.2023
#### Version 16.0.1.0.0
#### ADD

- Initial commit for Create Expense From Task
