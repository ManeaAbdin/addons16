## Module <login_user_detail>

#### 01.09.2022
#### Version 16.0.1.0.0
#### ADD
- Initial Commit for login_user_details