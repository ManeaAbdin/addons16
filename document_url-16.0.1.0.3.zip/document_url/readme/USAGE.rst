To use this module, you need to:

#. Open the form view of an object (Example: Customer Invoice INV/2019/0007).
#. Go to the chatter and click on the attached icon.
#. Click **Add URL** link.
#. Fill the wizard fields and click on Add button.
#. You will see a new **URL attachment** in the set of attachments related to
   the object.
