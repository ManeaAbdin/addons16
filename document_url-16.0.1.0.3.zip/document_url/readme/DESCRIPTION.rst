Module that allows to attach an URL as a document.
