This module removes enterprise-only apps and features from all settings views.

It also removes the widget in the General Settings page for downloading the Odoo
mobile apps from Google Play and Apple Store.
