## Module <low_stocks_product_alert>

#### 27.07.2023
#### Version 16.0.1.0.0
#### ADD

- Initial commit for Product Low Stock Alert